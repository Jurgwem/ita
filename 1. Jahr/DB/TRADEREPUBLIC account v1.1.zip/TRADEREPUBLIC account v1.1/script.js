var abschluss = document.getElementById("abschluss");
var interesse = document.getElementById("interesse");
var output = document.getElementById("empfehlung");
var spacer = document.createElement("div")
let searchbar = document.getElementById("searchbar");
let searchValue = "";
let search_btn = document.getElementById("search_button");
search_btn.addEventListener("click",  search);
let  reset_btn = document.getElementById("reset_button");
reset_btn.addEventListener("click", reset);

spacer.innerHTML = "<br><br>";

function search() {
    abschluss.innerHTML = "";
    interesse.innerHTML = "";
    output.innerHTML = "";
    searchValue = searchbar.value;
    if (searchValue == "") {
        fetch('datenbank.json') 
            .then(response => response.json())
            .then(datenbank => {
                console.log(datenbank);

                for (var x = 0; x < datenbank.Schulabschlüsse.length; x++) {
                    var child = document.createElement("div")
                    child.innerHTML = datenbank.Schulabschlüsse[x].AB_ID + " - " + datenbank.Schulabschlüsse[x].Abschlussname;
                    abschluss.appendChild(child);
                }
            
                abschluss.appendChild(spacer);

                for (var x = 0; x < datenbank.Bildungsgänge.length; x++) {
                    var child = document.createElement("div")
                    if (datenbank.Bildungsgänge[x].B_ID < 10) {
                        child.innerHTML = "&nbsp&nbsp" + datenbank.Bildungsgänge[x].B_ID + " - " + datenbank.Bildungsgänge[x].Bildungsgang;
                    }
                    else {
                        child.innerHTML = datenbank.Bildungsgänge[x].B_ID + " - " + datenbank.Bildungsgänge[x].Bildungsgang;
                    }
                    output.appendChild(child);
                }

                output.appendChild(spacer);

                for (var x = 0; x < datenbank.Interessen.length; x++) {
                    var child = document.createElement("div")
                    if (datenbank.Interessen[x].I_ID < 10) {
                        child.innerHTML = "&nbsp&nbsp" + datenbank.Interessen[x].I_ID + " - " + datenbank.Interessen[x].Name;
                    }
                    else {
                        child.innerHTML = datenbank.Interessen[x].I_ID + " - " + datenbank.Interessen[x].Name;
                    }
                    interesse.appendChild(child);
                }

            })
            .catch(error => {
                console.error('wenn du das hier siehst dann RIP', error);
            });
    }
    else if (searchValue != "") {
        console.log(searchValue);
        fetch('datenbank.json') 
            .then(response => response.json())
            .then(datenbank => {
                //console.log(datenbank);

                for (var x = 0; x < datenbank.Schulabschlüsse.length; x++) {
                    console.log(datenbank.Schulabschlüsse[x].Abschlussname);
                }

                for (var x = 0; x < datenbank.Schulabschlüsse.length; x++) {
                    if (datenbank.Schulabschlüsse[x].Abschlussname == searchValue) {
                        console.log("Abschluss - happy");
                        var child = document.createElement("div");
                        child.innerHTML = datenbank.Schulabschlüsse[x].AB_ID + " - " + datenbank.Schulabschlüsse[x].Abschlussname;
                        abschluss.innerHTML = "";
                        abschluss.appendChild(child);
                        break;
                    }
                    else if (datenbank.Schulabschlüsse.Abschlussname != searchValue) {
                        console.log("Abschluss - not so happy");
                        let child = document.createElement("div");
                        abschluss.innerHTML = "";
                        child.innerHTML = "<b>Keine Treffer</b>";
                        abschluss.appendChild(child);
                    }
                }
            
                output.appendChild(spacer);

                for (var x = 0; x < datenbank.Interessen.length; x++) {
                    if (datenbank.Interessen[x].Name == searchValue) {
                        var child = document.createElement("div")
                        child.innerHTML = datenbank.Interessen[x].I_ID + " - " + datenbank.Interessen[x].Name;
                        interesse.innerHTML = "";
                        interesse.appendChild(child);
                        break;
                    }
                    else if (datenbank.Interessen.Name != searchValue) {
                        let child = document.createElement("div");
                        interesse.innerHTML = "";
                        child.innerHTML = "<b>Keine Treffer</b>";
                        interesse.appendChild(child);
                    }
                }

                output.appendChild(spacer);

                for (var x = 0; x < datenbank.Bildungsgänge.length; x++) {
                    if (datenbank.Bildungsgänge[x].Bildungsgang == searchValue) {
                        var child = document.createElement("div")
                        child.innerHTML = datenbank.Bildungsgänge[x].AB_ID + " - " + datenbank.Bildungsgänge[x].Bildungsgang;
                        output.innerHTML = "";
                        output.appendChild(child);
                        break;
                    }
                    else if (datenbank.Bildungsgänge.Bildungsgang != searchValue) {
                        let child = document.createElement("div");
                        output.innerHTML = "";
                        child.innerHTML = "<b>Keine Treffer</b>";
                        output.appendChild(child);
                    }
                }

            })
            .catch(error => {
                console.error('wenn du das hier siehst dann RIP', error);
            });
    }
}

function reset() {
    window.location.reload();
}

search();